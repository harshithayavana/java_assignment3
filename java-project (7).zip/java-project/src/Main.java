import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        HashMap<String, Integer> map = new HashMap<>();

        System.out.println("Enter a sentence:");
        String sentence = sc.nextLine().toLowerCase();

        String[] words = sentence.split("\\W+");

        // Count word frequency
        for (String word : words) {
            if (!word.isEmpty()) {
                map.put(word, map.getOrDefault(word, 0) + 1);
            }
        }

        // Write output to file
        try {
            FileWriter fw = new FileWriter("output.txt");

            for (String word : map.keySet()) {
                fw.write(word + " : " + map.get(word) + "\n");
            }

            fw.close();

            System.out.println("Word frequency calculated successfully!");
            System.out.println("Output saved in output.txt");

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }

        sc.close();
    }
}

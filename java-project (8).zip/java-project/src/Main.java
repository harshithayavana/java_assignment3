import java.util.*;
import java.io.*;

class Employee {
    int id;
    String name;
    String department;
    double salary;

    Employee(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Department: " + department);
        System.out.println("Salary: " + salary);
        System.out.println("--------------------");
    }
}

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ArrayList<Employee> employees = new ArrayList<>();

        try {
            System.out.print("Enter number of employees: ");
            int n = sc.nextInt();
            sc.nextLine();

            // Store employee details
            for (int i = 0; i < n; i++) {

                System.out.println("\nEnter Employee " + (i + 1) + " Details");

                System.out.print("Enter ID: ");
                int id = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter Name: ");
                String name = sc.nextLine();

                System.out.print("Enter Department: ");
                String department = sc.nextLine();

                System.out.print("Enter Salary: ");
                double salary = sc.nextDouble();
                sc.nextLine();

                if (id <= 0 || salary < 0 || name.trim().isEmpty()
                        || department.trim().isEmpty()) {
                    throw new IllegalArgumentException("Invalid employee details!");
                }

                employees.add(new Employee(id, name, department, salary));
            }

            // Save data to file
            FileWriter fw = new FileWriter("employees.txt");

            for (Employee e : employees) {
                fw.write(e.id + "," + e.name + "," +
                         e.department + "," + e.salary + "\n");
            }

            fw.close();

            System.out.println("\nEmployee data saved successfully!");

            // Load data from file
            System.out.println("\nEmployee Details from File:");

            BufferedReader br = new BufferedReader(
                new FileReader("employees.txt"));

            String line;

            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");

                Employee e = new Employee(
                    Integer.parseInt(data[0]),
                    data[1],
                    data[2],
                    Double.parseDouble(data[3])
                );

                e.display();
            }

            br.close();

        } catch (InputMismatchException e) {
            System.out.println("Error: Please enter valid input!");

        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());

        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());

        } finally {
            sc.close();
        }
    }
}
